const CACHE_NAME = "arabtv-shell-v1";
const APP_SHELL = [
  "./index.html",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "./icon-512-maskable.png"
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).catch(() => {})
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    )
  );
  self.clients.claim();
});

// شبكة أولًا (network-first) لملفات التطبيق، مع رجوع للكاش عند انقطاع الاتصال.
// روابط البث نفسها (m3u8 وملفات الفيديو) لا تُخزَّن أبدًا هنا، تُطلب دائمًا مباشرة من الشبكة.
self.addEventListener("fetch", (event) => {
  const url = event.request.url;

  if (url.includes(".m3u8") || url.includes(".ts") || event.request.method !== "GET") {
    return; // اترك طلبات البث كما هي بدون أي تدخل
  }

  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
